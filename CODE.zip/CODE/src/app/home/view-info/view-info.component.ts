import { Component, OnInit, Input, OnDestroy, ViewChild } from '@angular/core';
import { IUserInfo, UserInfo } from '../../dataTypes/UserInfo';
import { UserInfoService } from '../../services/userInfo.service';
import { IUser } from '../../dataTypes/user';
import { Time } from '@angular/common';
import { IRelativeInfo } from '../../dataTypes/RelativeInfo';
import { UsersService } from '../../services/users.service';
import { Subscription } from 'rxjs/Subscription';
import { NgForm, Form } from '@angular/forms';

@Component({
  selector: 'app-view-info',
  templateUrl: './view-info.component.html',
  styleUrls: ['./view-info.component.css']
})
export class ViewInfoComponent implements OnInit, OnDestroy {
  @ViewChild('f') userform: NgForm;
  subscription: Subscription;
  editMode = false;
  editedIndex: number;
  userInfo : UserInfo;

  private _userInfoService;
  private _usersService;
  private errorMessage: string;
  @Input() user: IUser;
  userJson: IUserInfo[] = [];
  userInfos: IUserInfo[] = [];

  relatives = [];

  constructor(
    private userInfoService: UserInfoService,
    private usersService: UsersService) {
    console.log("constructor called");
    this._userInfoService = userInfoService;
    this._usersService = usersService;
  }

  ngOnInit() {

    this.getData();

    this.subscription = this._usersService.startedEditing.subscribe(
      (index: number) => {
        this.editMode = true;
        this.editedIndex = index;
        this.putInUserInfoObject(this.userform);
        // this.userform.setValue({
        //   name: this.userInfos[0].Name,

       // })
      }
    );


  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getData() {
    this._userInfoService.getUserInfo(this.user)
      .subscribe(response => {
        this.userJson = response;
        this.userInfos = this.userJson;

        this.relatives.push(
          {
            Relation: this.userInfos[0].Father['Relation'] as string,
            Name: this.userInfos[0].Father['Name'] as string,
            Address: this.userInfos[0].Father['Address'] as string,
            Occupation: this.userInfos[0].Father['Occupation'] as string,
            PhoneNumber: this.userInfos[0].Father['PhoneNumber'] as string,
          },
          {
            Relation: this.userInfos[0].Mother['Relation'] as string,
            Name: this.userInfos[0].Mother['Name'] as string,
            Address: this.userInfos[0].Mother['Address'] as string,
            Occupation: this.userInfos[0].Mother['Occupation'] as string,
            PhoneNumber: this.userInfos[0].Mother['PhoneNumber'] as string,
          },
          {
            Relation: this.userInfos[0].Guardian['Relation'] as string,
            Name: this.userInfos[0].Guardian['Name'] as string,
            Address: this.userInfos[0].Guardian['Address'] as string,
            Occupation: this.userInfos[0].Guardian['Occupation'] as string,
            PhoneNumber: this.userInfos[0].Guardian['PhoneNumber'] as string,
          }
        );

      },
        error => this.errorMessage = <any>error);
  }

  putInUserInfoObject(formvalue: NgForm){
    const value = formvalue.value;
     this.userInfo = new UserInfo(
      value.date as Date,
      value.name as string,
      value.sex as string,
      value.dob as Date,
      value.height as number,
      value.complexion as string,
      value.educationOrQualification as string,
      value.star as string,
      value.pdm as string,
      value.dhosham as boolean,
      value.dhoshamType as string,
      value.birthtime as Time,
      value.birthplace as string,
      value.occupation as string,
      value.designation as string,
      value.companyname as string,
      value.salary as number,
      value.phoneNumber as string,
      value.brothers as number,
      value.brothersmarried as boolean,
      value.sisters as number,
      value.sistersmarried as boolean,
      value.descriptionOfReq as string,
      value.communityname as string,
      value.address as string,
      value.fathername as string,
      value.mothername as string,
      value.guardianname as string,
   );
  }
}
