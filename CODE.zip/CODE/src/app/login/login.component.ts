import { Component, OnInit } from '@angular/core';
import { MatInputModule } from '@angular/material/input';
import { Router } from '@angular/router';
import { UsersService } from '../services/users.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [MatInputModule]

})
export class LoginComponent implements OnInit {

  userName: string;
  password: string;
  message: boolean;

  constructor(private router: Router, private _userService: UsersService) {
    this._userService.changeMessage(false);
  }

  ngOnInit() {
    this._userService.currentMessage.subscribe(message => this.message = message)
  }

  onClickSubmit(): void {
    this.loginUser();
    console.log("login success");
    this.router.navigate(['./home']);
  }

  loginUser() {
    console.log("login user");
    this._userService.changeMessage(true);
  }

  ngOnDestroy() {
    console.log("set to false");
    this._userService.changeMessage(false);
 }

}
