export interface IUser{
    UserName : string;
    Password : string;   
}