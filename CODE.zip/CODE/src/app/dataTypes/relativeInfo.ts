export interface IRelativeInfo{
    Name: string;
    Address: string;
    Occupation: string;
    PhoneNumber: string;
}