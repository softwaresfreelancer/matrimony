export interface IContact{
    Name: string;
    Address: string;
    Occupation: string;
    PhoneNumber: string;
}