import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { UsersService } from '../services/users.service';


@Injectable()
export class AuthGuard {
  private _usersService;
  message: boolean;
  constructor(private userService: UsersService, private router: Router) {

  }
  ngOnIt() {
    this.userService.currentMessage.subscribe(message => this.message = message)
  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    console.log("check activation");
    if (this.userService.currentMessage) {
      console.log("check true");
      return true;
    }
    console.log("check false");
    // else navigate to login
    this.router.navigate(['./login']);
  }
}
