import { IUser } from "../dataTypes/user";
import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { Subject } from "rxjs/Subject";
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class UsersService {
    private url = '/assets/users-data.json';
    public startedEditing = new Subject<number>();
    private messageSource = new BehaviorSubject<boolean>(false);
    currentMessage = this.messageSource.asObservable();


    constructor(private _http: HttpClient) {
        this.changeMessage(false);
    }

    getUsers(): Observable<IUser[]> {
        return this._http.get<IUser[]>(this.url)
            .do(data => console.log('All:' + "user ids"))
            .catch(this.handleError);
    }

    private handleError(err: HttpErrorResponse) {
        console.log(err.message);
        return Observable.throw(err.message);
    }

    changeMessage(message: boolean) {
        console.log("change status"+ message);
        this.messageSource.next(message)
    }

    ngOnDestroy() {
        console.log("set to false");
        this.changeMessage(false);
     }
}